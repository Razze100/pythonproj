print("\033[1;31;40m Bright Red \n")
print("\033[1;37;40m Bright Colour\033[0;37;40m \n")